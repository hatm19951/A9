package sortieren;


public class Sortieren {

	public static void main(String[] args) {
		
		String[] feld1 = { "aaa", "bba", "aba", "aab" };
		String[] feld2 = { "aba", "baaza", "cccba", "abab", "bab", "baaaa", "bazbab" };
		
		buchstabenFinder(feld1);
		
	}
	
	static void buchstabenFinder(String[] feld) {
		int invz = 0;
		for(int i=0; i < feld.length -1; i++) {
			String wort1 = feld[i];
			for(int j=i+1; j < feld.length; j++) {
				String wort2 = feld[j];
				int position1 = wort1.indexOf('a');
				int position2 =	wort2.indexOf('a');
				System.out.println(wort1 +" <> " + wort2);
				
				if(position1 > position2) {
					invz++;
				}
				
				if(position1 == position2) {
					int position3 = wort1.lastIndexOf('b') + wort1.length();
					int position4 = wort2.lastIndexOf('b')+wort2.length();
					if( position3 < position4) {
						invz++;
					}
				}
				System.out.println(invz);
			}	
		}
		
	}
}
	
	
	

