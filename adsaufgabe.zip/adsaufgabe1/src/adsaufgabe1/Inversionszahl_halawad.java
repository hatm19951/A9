package adsaufgabe1;


// Der Konstruktor der Klasse darf keine formalen Parameter (Argumente) 
// enthalten

public class Inversionszahl_halawad implements IInversionszahl {

    // Konstruktor ohne Argumente bitte belassen
    public Inversionszahl_halawad() {
    	
    }

    public int berechne(String[] feld) {
	// Hier steht Ihre Inversionsort-Implementation, die
	// die Inversionszahl ermittelt
    	InversionszahlErmitteler(feld);
	return 0;
    }

    // Ggf. bietet es sich an, Hilfsmethoden zum Vergleich der
    // Strings als private Methode zu implementieren
    
    static int InversionszahlErmitteler(String[] feld) {
		int invzahl = 0;
		for(int i=0; i < feld.length -1; i++) {
			String wort1 = feld[i];
			for(int j=i+1; j < feld.length; j++) {
				String wort2 = feld[j];
				int position1 = wort1.indexOf('a');
				int position2 =	wort2.indexOf('a');
				
				if(position1 > position2) {
					invzahl++;
				}
				
				if(position1 == position2) {
					int position3 = wort1.lastIndexOf('b') + wort1.length();
					int position4 = wort2.lastIndexOf('b')+ wort2.length();
					if( position3 < position4) {
						invzahl++;
					}
				}
			}	
		}
		return invzahl;
		
	}
}
